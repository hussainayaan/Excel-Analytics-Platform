const express = require('express');
const upload = require('../middleware/upload');
const XLSX = require('xlsx');
const fs = require('fs');

const router = express.Router();

router.post('/', upload.single('file'), (req, res) => {
  try {
    const filePath = req.file.path;
    const workbook = XLSX.readFile(filePath);
    const sheetName = workbook.SheetNames[0];
    const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);

    fs.unlinkSync(filePath); // delete file after parsing

    res.json({ data: jsonData });
  } catch (err) {
    res.status(500).json({ error: 'Error processing file' });
  }
});

module.exports = router;