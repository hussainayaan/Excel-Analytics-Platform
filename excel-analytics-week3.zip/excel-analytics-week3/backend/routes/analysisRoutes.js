// Express routes for analysis
