// Mongoose model for analysis history
