// Controller for handling analysis and history
