// Function to call AI API for summary
